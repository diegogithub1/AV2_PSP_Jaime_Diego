package es.florida.ae2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

public class servidor {
	private static ArrayList<Integer> posOcupadas = new ArrayList<Integer>();
	private static int turn = 0;

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		System.err.println("SERVIDOR >>> Arranca el servidor");
		ServerSocket socketEscucha = null;
		try {
			socketEscucha = new ServerSocket(1234);
		} catch (IOException e) {
			System.err.println("SERVIDOR >>> Error");
			return;
		}
		while (true)  {
 
 	    	/*
 	    	 * Abrimos la conexion con el cliente y recibimos un dato que se refiere a una posicion
 	    	 * del tablero que se añade a una array de numero que simulan las casillas ocupadas
 	    	 * y va añadiendo las que el mismo genera aleatoriamente para que luego desde el cliente
 	    	 * se refleje en el tablero
 	    	 * */

			Socket conexion = socketEscucha.accept();
			ObjectInputStream inObjeto = new ObjectInputStream(conexion.getInputStream());
			int pos = (int) inObjeto.readObject();
			if (pos != 35) {
			System.err.println("SERVIDOR >> Casilla marcada por cliente: " + pos);
			posOcupadas.add(pos);
			System.out.println("Turno servidor inicio --> " + turn);
			turn++;
			
			// RANDOM SERVERv   

			ObjectOutputStream dato = new ObjectOutputStream(conexion.getOutputStream());
			
			if (turn  <8 ) { 
			
			
			Random random = new Random();
			int number = random.nextInt(10);
			do {
				number = random.nextInt(10);
			} while (posOcupadas.contains(number) || number == 0);
			System.out.println("NUMERO DEL SERVER : " + number);
			dato.writeObject(number);
			posOcupadas.add(number);
			turn++;
			
			
			}else {
				/*
				 * La aplicacion cuando llega al turno mayor que 9  finaliza o en EMPATE o en que uno
				 * de los dos gane
				 * */
				System.out.println("FIN");
				posOcupadas.clear();
				turn = 0;
				dato.writeObject(20);
				
			}
			System.out.println(posOcupadas.toString());
			}else {
				posOcupadas.clear();
				turn = 0;
			}
		}

	}
}