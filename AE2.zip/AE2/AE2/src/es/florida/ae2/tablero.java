package es.florida.ae2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class tablero extends JFrame {

	private JPanel contentPane;

	// Inicializamos las variables externamente y los botones para posteriormente
	// poder acceder desde las funciones externas
	// y poder agregarlas todas en un array para poder establecerles las mismas
	// propiedades a todos sin tener que
	// agregarlas 1 por 1.

	public JButton btn_1 = new JButton("");
	private JButton btn_2 = new JButton("");
	private JButton btn_3 = new JButton("");
	private JButton btn_4 = new JButton("");
	private JButton btn_5 = new JButton("");
	private JButton btn_6 = new JButton("");
	private JButton btn_7 = new JButton("");
	private JButton btn_8 = new JButton("");
	private JButton btn_9 = new JButton("");
	private JButton btn[] = new JButton[9];
	private JLabel lblNewLabel_2 = new JLabel("0");
	int turno = 0;
	int va[][] = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 }, { 1, 4, 7 }, { 2, 5, 8 }, { 3, 6, 9 }, { 1, 5, 9 },{ 3, 5, 7 } };
			

	/**
	 * Launch the application.
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					tablero frame = new tablero();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	
	
	/**
	 * Con esta funcion reestablecemos las variables a su valor inicial para poder
	 * despues poder jugar mas de una sola vez , est una funcion de tipo void es
	 * decir que no devuelve ningun tipo de dato 
	 */
	public void ClearVariables() {

		btn_1.setText("");
		btn_2.setText("");
		btn_3.setText("");
		btn_4.setText("");
		btn_5.setText("");
		btn_6.setText("");
		btn_7.setText("");
		btn_8.setText("");
		btn_9.setText("");
		lblNewLabel_2.setText("");
		turno = 0;
	}

	/**
	 * En esta funcion introducimos el turno por el que va el juego y mediante un
	 * cálculo para saber si el numero introducido es par o impar determinamos el
	 * caracter con el que se marcara la casilla en la que el jugador o el servidor
	 * @param turno
	 * @return devuelve un string que es el caracter que le corresponde al turno
	 */
	public String calTurno(Integer turno) {
		if (turno % 2 == 0) {
			return "X";
		} else {
			return "O";
		}
	}


	
	/**
	 * Esta es la funcion mas importante de la aplicacion porque desde aqui se establece
	 * la conexion del tablero con el servidor , solo le damos la posicion en la que 
	 * hay que marcar y se la mandamos al servidor y este nos devuelve otra que no coincida
	 * con las ya marcadas.
	 * @param casilla
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void presionar(int casilla) throws IOException, ClassNotFoundException {
		if (btn[casilla - 1].getText().equals("")) {

			String host = "localhost";
			int puerto = 1234;
			Socket cliente = new Socket(host, puerto);
			ObjectOutputStream objetoMandar = new ObjectOutputStream(cliente.getOutputStream());
			btn[casilla - 1].setText(calTurno(turno));
			turno++;
			if (comprobarGanador() == false) {
				objetoMandar.writeObject(casilla);
				System.out.println("CLIENTE >> Envio al servidor: " + casilla);
				ObjectInputStream inObjeto = new ObjectInputStream(cliente.getInputStream());
				int respuestaserver = (int) inObjeto.readObject();
				if (respuestaserver != 20) {
					System.out.println("CLIENTE >> Recibo del servidor: " + (respuestaserver + 1));
					btn[respuestaserver - 1].setText(calTurno(turno));
					turno++;
					lblNewLabel_2.setText("" + turno);
				} else {
					lblNewLabel_2.setText("PARTIDA TERMINADA ");
					turno = 0;
				}
			} else {
				JOptionPane.showMessageDialog(null, "PARTIDA TERMINADA GANAN VERDES", "", JOptionPane.WARNING_MESSAGE);
				objetoMandar.writeObject(35);
				ClearVariables();
			}
			if (comprobarGanador() != false) {
				JOptionPane.showMessageDialog(null, "PARTIDA TERMINADA GANAN ROJOS", "", JOptionPane.WARNING_MESSAGE);
				objetoMandar.writeObject(35);
				ClearVariables();
			}
			cliente.close();
		}
	}

	
	/**
	 * En esta funcion comprobamos si alguna de las dos partes ha ganado y ofrecemos una ventana
	 * en la que el usuario decida si quiere continuar jugando o en el otro caso se cierra
	 * la aplicacion 
	 * @return Booleano que demuestra quien ha ganado si es que ha ganado alguien
	 */
	public boolean comprobarGanador() {
		boolean compro = false;

		for (int i = 0; i < va.length; i++) {
			if (btn[va[i][0] - 1].getText().equals("X") && btn[va[i][1] - 1].getText().equals("X")
					&& btn[va[i][2] - 1].getText().equals("X")) {

				int resp = JOptionPane.showConfirmDialog(null, "¿Quieres seguir jugando", "Atencion!",
						JOptionPane.YES_NO_OPTION);
				if (resp == 1) {

					btn[va[i][0] - 1].setBackground(Color.green);
					btn[va[i][1] - 1].setBackground(Color.green);
					btn[va[i][2] - 1].setBackground(Color.green);
					for (JButton jButton : btn) {
						jButton.setEnabled(false);
					}
					System.exit(0);
				} else {
					compro = true;
				}
  
			} else

			if (btn[va[i][0] - 1].getText().equals("O") && btn[va[i][1] - 1].getText().equals("O")
					&& btn[va[i][2] - 1].getText().equals("O")) {
				int resp = JOptionPane.showConfirmDialog(null, "¿Quieres seguir jugando", "Atencion!",
						JOptionPane.YES_NO_OPTION);
				if (resp == 1) {
					btn[va[i][0] - 1].setBackground(Color.red);
					btn[va[i][1] - 1].setBackground(Color.red);
					btn[va[i][2] - 1].setBackground(Color.red);
					for (JButton jButton : btn) {
						jButton.setEnabled(false);
					}
					System.exit(0);

				} else {
					compro = true;
				}
			}

		}
		return compro;
	}

	/**
	 * Create the frame.
	 */
	public tablero() throws UnknownHostException, IOException, ClassNotFoundException {

		btn[0] = btn_1;
		btn[1] = btn_2;
		btn[2] = btn_3;
		btn[3] = btn_4;
		btn[4] = btn_5;
		btn[5] = btn_6;
		btn[6] = btn_7;
		btn[7] = btn_8;
		btn[8] = btn_9;

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 257, 349);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("TRES EN RAYA");
		lblNewLabel.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 17));
		lblNewLabel.setBounds(28, 9, 119, 25);
		contentPane.add(lblNewLabel);
		btn_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(1);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btn_1.setForeground(new Color(0, 0, 0));

		btn_1.setBackground(new Color(255, 255, 255));

		btn_1.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_1.setBounds(28, 64, 55, 55);
		contentPane.add(btn_1);
		btn_2.setForeground(new Color(0, 0, 0));

		btn_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(2);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btn_2.setBackground(new Color(255, 255, 255));
		btn_2.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_2.setBounds(93, 64, 55, 55);
		contentPane.add(btn_2);
		btn_5.setForeground(new Color(0, 0, 0));
		btn_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(5);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btn_5.setBackground(new Color(255, 255, 255));
		btn_5.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_5.setBounds(93, 130, 55, 55);
		contentPane.add(btn_5);
		btn_3.setForeground(new Color(0, 0, 0));
		btn_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(3);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btn_3.setBackground(new Color(255, 255, 255));
		btn_3.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_3.setBounds(158, 64, 55, 55);
		contentPane.add(btn_3);
		btn_4.setForeground(new Color(0, 0, 0));
		btn_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(4);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btn_4.setBackground(new Color(255, 255, 255));
		btn_4.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_4.setBounds(28, 130, 55, 55);
		contentPane.add(btn_4);
		btn_6.setForeground(new Color(0, 0, 0));
		btn_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(6);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btn_6.setBackground(new Color(255, 255, 255));
		btn_6.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_6.setBounds(158, 130, 55, 55);
		contentPane.add(btn_6);
		btn_7.setForeground(new Color(0, 0, 0));
		btn_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(7);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btn_7.setBackground(new Color(255, 255, 255));
		btn_7.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_7.setBounds(28, 196, 55, 55);
		contentPane.add(btn_7);
		btn_8.setForeground(new Color(0, 0, 0));
		btn_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(8);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});

		btn_8.setBackground(new Color(255, 255, 255));
		btn_8.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_8.setBounds(93, 196, 55, 55);
		contentPane.add(btn_8);
		btn_9.setForeground(new Color(0, 0, 0));
		btn_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					presionar(9);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		btn_9.setBackground(new Color(255, 255, 255));
		btn_9.setFont(new Font("Segoe UI", Font.PLAIN, 28));
		btn_9.setBounds(158, 196, 55, 55);
		contentPane.add(btn_9);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.BLACK);
		panel_1.setBounds(28, 64, 185, 187);
		contentPane.add(panel_1);

		JLabel lblNewLabel_1 = new JLabel("TURNO : ");
		lblNewLabel_1.setBounds(24, 272, 59, 14);
		contentPane.add(lblNewLabel_1);

		lblNewLabel_2.setBounds(78, 272, 135, 14);
		contentPane.add(lblNewLabel_2);

	}
}